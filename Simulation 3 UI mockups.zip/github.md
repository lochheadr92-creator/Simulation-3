repo: lochheadr92-creator/Simulation-3
branch: codex/kernel-first-slice
path: world/

## Last sync
date: 2026-09-27T20:14:16Z

### Updated in this project
- Three new directions for the map viewer, with real-time 3D models and textures
- The world layout, needs, sources, homes, shelters and errands come from the repo docs

## Screen map
| Screen | Repo files |
| --- | --- |
| Sim3 Viewer Directions.dc.html (1a, 1b, 1c) | world/viewer.css, world/viewer.js, WORLD_DIRECTIONS.md, ROADMAP.md |
| sim-world.js (3D diorama) | world/viewer.py, world/config.py |

(function(){
if(customElements.get('sim-world'))return;
const URL3='https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
let p3;const three=()=>p3||(p3=import(URL3));
const N=12,H=N/2-.5;
function rng(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function hash2(x,y,s){let h=Math.imul((x|0)*374761393+(y|0)*668265263+(s|0)*1442695041|0,1274126177);h^=h>>>13;h=Math.imul(h,1274126177);return((h^h>>>16)>>>0)/4294967296}
function vnoise(x,y,s){const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi;const u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf);const a=hash2(xi,yi,s),b=hash2(xi+1,yi,s),c=hash2(xi,yi+1,s),d=hash2(xi+1,yi+1,s);return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v}
function fbm(x,y,s){let f=0,a=.5,fr=1;for(let i=0;i<4;i++){f+=a*vnoise(x*fr,y*fr,s+i*17);a*=.5;fr*=2}return f/.9375}
const key=(i,j)=>i+','+j;
const BUSH=[[2,3],[9,8]],WELL=[[8,2],[3,9]],STOCK=[7,4];
const HOMES=[[5,5,1],[6,4,1],[4,7,.66],[7,7,1],[2,6,1],[9,5,0]];
const SPOT=[[6,10],[10,1]];
const feat=new Map();
BUSH.forEach((c,k)=>feat.set(key(c[0],c[1]),{t:'bush',k}));
WELL.forEach((c,k)=>feat.set(key(c[0],c[1]),{t:'well',k}));
HOMES.forEach((c,k)=>feat.set(key(c[0],c[1]),{t:'home',k,p:c[2]}));
SPOT.forEach((c,k)=>feat.set(key(c[0],c[1]),{t:'spot',k}));
const PEOPLE=[
 {id:'p01',color:'#c9a46a',skin:'#e8c6a3',hair:'#3b2a20',route:[[5,5],[2,3]],need:'#f2a65e'},
 {id:'p02',color:'#6f9fc8',skin:'#c99a74',hair:'#1f1a18',route:[[6,4],[8,2]],need:'#72c8ea',carry:'water'},
 {id:'p03',color:'#c77b6b',skin:'#a8744f',hair:'#2a1d16',route:[[4,7]],work:true},
 {id:'p04',color:'#8fb87a',skin:'#f0d2b4',hair:'#7a4b2a',route:[[7,7],[9,8],[9,5]],carry:'food'},
 {id:'p05',color:'#ae8ac6',skin:'#b88560',hair:'#161214',route:[[2,6],[3,9]],need:'#72c8ea'},
 {id:'p06',color:'#d4bf6c',skin:'#dcb08a',hair:'#4a3020',route:[[9,5]],need:'#ff6f5e',sit:true,emergency:true}
];
function walk(a,b){const o=[];let x=a[0],y=a[1];while(x!==b[0]){x+=Math.sign(b[0]-x);o.push([x,y])}while(y!==b[1]){y+=Math.sign(b[1]-y);o.push([x,y])}return o}
const VIS=new Map();
const cellXZ=c=>{const f=feat.get(key(c[0],c[1]));const o=f&&f.t!=='spot'?.3:0;return[c[0]-H+o,c[1]-H+o]};
PEOPLE.forEach((p,i)=>{p.phase=i*5;const r=p.route,cells=[];
 if(r.length===1)cells.push(r[0]);else{const pts=[...r,r[0]];cells.push(r[0],r[0],r[0]);let cur=r[0];for(let k=1;k<pts.length;k++){walk(cur,pts[k]).forEach(c=>cells.push(c));if(k<pts.length-1)cells.push(pts[k],pts[k],pts[k]);cur=pts[k]}}
 cells.forEach(c=>VIS.set(key(c[0],c[1]),(VIS.get(key(c[0],c[1]))||0)+1));p.frames=cells.map(cellXZ)});
const ROUGH=new Set();{const r=rng(11);for(let i=0;i<N;i++)for(let j=0;j<N;j++){const k=key(i,j);if(!feat.has(k)&&!VIS.has(k)&&r()<.26)ROUGH.add(k)}}
const PAL={
 tabletop:{exp:1.0,fov:24,dist:36,el:.7,grass:['#7e9f55','#96b566'],dirt:'#b39c74',rough:'#8f8166',spot:'#6f8f5a',plinth:'#5b3f2b',base:'#2e2119',rock:'#a19b90',leaf:['#5f8a3e','#77a04a','#4e7a38'],bark:'#6b4b33',wall:'#e6d8bb',roof:'#a8573a',wood:'#8a6444',stone:'#aca69c',water:'#2f7fa3',sun:['#fff0d8',3.1,[9,15,5]],hemi:['#d6ddff','#4a3a2c',1.15],fill:['#b9c4ff',.35],tuft:'#6f9848'},
 night:{exp:1.25,fov:24,dist:36,el:.74,grass:['#2e4a48','#375850'],dirt:'#4b4b55',rough:'#3a3d4c',spot:'#2f4a4a',plinth:'#1b1d2b',base:'#12131d',rock:'#5d6172',leaf:['#23403a','#2c4d44','#1d3833'],bark:'#3a3030',wall:'#8d8aa0',roof:'#463c5a',wood:'#4b4050',stone:'#6c6f80',water:'#2a6f95',sun:['#aab8ff',1.7,[-7,14,-6]],hemi:['#5a66b0','#0e0f18',.75],fill:['#9184d9',.9],tuft:'#2e4e46',night:true},
 island:{island:true,exp:1.05,fov:28,dist:31,el:.58,grass:['#789b4a','#91b05a'],dirt:'#a88f68',rough:'#857b6c',rock:'#8f8a82',leaf:['#557f37','#6e9840','#4a7431'],bark:'#5e4330',wall:'#e2d1b0',roof:'#8f5a3a',wood:'#8a6444',stone:'#a39d92',water:'#3b8fb0',sun:['#ffd3a0',3.5,[-11,9,7]],hemi:['#c0ccff','#50402e',1.0],fill:['#9fb0ff',.5],tuft:'#6a9142'},
 dusk:{island:true,night:true,exp:1.2,fov:28,dist:31,el:.58,grass:['#4f6a44','#627a4c'],dirt:'#7d6a58',rough:'#665e5a',rock:'#77716e',leaf:['#3d5a34','#4c6a3a','#34502e'],bark:'#4a3528',wall:'#c9b49c',roof:'#6e4436',wood:'#6e5040',stone:'#8a8480',water:'#3a7fa8',sun:['#ff9a6a',2.4,[-12,5,6]],hemi:['#7b7fc8','#2a2030',.85],fill:['#9184d9',.7],tuft:'#4c6840'}
};
function makeTex(T,size,fn,rep){const c=document.createElement('canvas');c.width=c.height=size;const x=c.getContext('2d');const im=x.createImageData(size,size);for(let j=0;j<size;j++)for(let i=0;i<size;i++){const v=Math.max(0,Math.min(1,fn(i,j)))*255,o=(j*size+i)*4;im.data[o]=im.data[o+1]=im.data[o+2]=v;im.data[o+3]=255}x.putImageData(im,0,0);const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.colorSpace=T.SRGBColorSpace;if(rep)t.repeat.set(rep,rep);t.anisotropy=4;return t}
function tileGeo(T,size,h,r,bev){const s=size/2-bev;const sh=new T.Shape();sh.moveTo(-s+r,-s);sh.lineTo(s-r,-s);sh.quadraticCurveTo(s,-s,s,-s+r);sh.lineTo(s,s-r);sh.quadraticCurveTo(s,s,s-r,s);sh.lineTo(-s+r,s);sh.quadraticCurveTo(-s,s,-s,s-r);sh.lineTo(-s,-s+r);sh.quadraticCurveTo(-s,-s,-s+r,-s);const g=new T.ExtrudeGeometry(sh,{depth:h-2*bev,bevelEnabled:true,bevelThickness:bev,bevelSize:bev,bevelSegments:3,curveSegments:5});g.rotateX(-Math.PI/2);g.translate(0,bev,0);return g}
function blobGeo(T,r,seed,amp){const g=new T.SphereGeometry(r,22,16);const p=g.attributes.position,v=new T.Vector3();for(let i=0;i<p.count;i++){v.fromBufferAttribute(p,i);const n=fbm(v.x*7+seed,v.y*7+v.z*5+seed*1.7,seed|0);v.multiplyScalar(1+amp*(n-.5));p.setXYZ(i,v.x,v.y,v.z)}g.computeVertexNormals();return g}

class SimWorld extends HTMLElement{
 static get observedAttributes(){return['variant','playing','focus']}
 set variant(v){if(this._v===v)return;this._v=v;if(this._R){this._teardown();three().then(T=>{if(this._on)this._build(T)})}}get variant(){return this._v||this.getAttribute('variant')||'tabletop'}
 set playing(v){this._p=v}get isPlaying(){const a=this._p!=null?String(this._p):this.getAttribute('playing');return a!=='off'&&a!=='false'}
 set focus(v){this._f=v}get focusId(){return this._f||this.getAttribute('focus')||''}
 connectedCallback(){if(this._on)return;this._on=true;this.style.display='block';this.style.position=this.style.position||'relative';this.style.width=this.style.width||'100%';this.style.height=this.style.height||'100%';three().then(T=>{if(this._on)this._build(T)}).catch(()=>{this.textContent='3D view unavailable'})}
 disconnectedCallback(){this._on=false;this._teardown()}
 _teardown(){cancelAnimationFrame(this._raf);this._ro&&this._ro.disconnect();this._io&&this._io.disconnect();if(this._R){this._R.dispose();this._R.domElement.remove();this._R=null}}
 _build(T){
  const V=PAL[this.variant]?this.variant:'tabletop',P=PAL[V],night=!!P.night,island=!!P.island;
  const R=new T.WebGLRenderer({antialias:true,alpha:true});this._R=R;
  R.setPixelRatio(Math.min(window.devicePixelRatio||1,2));R.shadowMap.enabled=true;R.shadowMap.type=T.PCFSoftShadowMap;R.toneMapping=T.ACESFilmicToneMapping;R.toneMappingExposure=P.exp;R.outputColorSpace=T.SRGBColorSpace;R.setClearColor(0,0);
  const cv=R.domElement;cv.style.cssText='position:absolute;inset:0;width:100%;height:100%;display:block;cursor:grab;touch-action:none';this.appendChild(cv);
  const S=new T.Scene(),cam=new T.PerspectiveCamera(P.fov,1,.1,300);
  if(night)S.fog=new T.Fog('#161826',40,72);
  const C=c=>new T.Color(c);
  const M=(c,o)=>new T.MeshStandardMaterial(Object.assign({color:c,roughness:.85,metalness:0},o||{}));
  const cast=o=>{o.traverse(m=>{if(m.isMesh){m.castShadow=true;m.receiveShadow=true}});return o};
  const tGrain=makeTex(T,128,(x,y)=>.8+.22*(fbm(x/12,y/12,3)-.5)+.07*(hash2(x,y,1)-.5));
  const tWood=makeTex(T,256,(x,y)=>.78+.28*(fbm(x/70,y/2.5,8)-.5)+.05*hash2(x,y,2));
  const tStone=makeTex(T,128,(x,y)=>.8+.35*(fbm(x/9,y/9,4)-.5)+.06*hash2(x,y,5));
  const gTex=(()=>{const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d');const g=x.createRadialGradient(32,32,0,32,32,32);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.22,'rgba(255,255,255,.5)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,64,64);const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;return t})();
  const glow=(color,size,op)=>{const s=new T.Sprite(new T.SpriteMaterial({map:gTex,color,transparent:true,blending:T.AdditiveBlending,depthWrite:false,opacity:op==null?1:op}));s.scale.set(size,size,1);return s};
  // heights
  let top;
  if(island){const cache={};const CH=(i,j)=>{const k=key(i,j);if(cache[k]!=null)return cache[k];let h=.3+.7*fbm((i+3)*.19,(j+5)*.19,5);if(ROUGH.has(k))h+=.12;return cache[k]=h};
   top=(x,z)=>{const u=x+H,v=z+H,i=Math.floor(u),j=Math.floor(v),su=(u-i)*(u-i)*(3-2*(u-i)),sv=(v-j)*(v-j)*(3-2*(v-j));const a=CH(i,j),b=CH(i+1,j),c=CH(i,j+1),d=CH(i+1,j+1);return a+(b-a)*su+(c-a)*sv+(a-b-c+d)*su*sv+.05*(fbm(x*1.4+20,z*1.4+20,9)-.5)}}
  else{const TT=(i,j)=>.3+(night?0:.05*hash2(i,j,77));const cl=v=>Math.max(0,Math.min(N-1,Math.round(v+H)));top=(x,z)=>TT(cl(x),cl(z));this._TT=TT}
  const rnd=rng(V==='night'?3:V==='island'?5:9);
  // ground
  if(!island){
   const TS=night?.9:.965,tg=tileGeo(T,TS,.3,.09,.03);
   const inst=new T.InstancedMesh(tg,M('#ffffff',{map:tGrain,roughness:.92}),N*N);inst.receiveShadow=true;inst.castShadow=true;
   const m4=new T.Matrix4(),col=new T.Color();let n=0;
   for(let i=0;i<N;i++)for(let j=0;j<N;j++){const k=key(i,j),f=feat.get(k);m4.makeTranslation(i-H,this._TT(i,j)-.3,j-H);inst.setMatrixAt(n,m4);
    col.set(P.grass[0]).lerp(C(P.grass[1]),hash2(i,j,3));col.lerp(C(P.dirt),Math.min(1,(VIS.get(k)||0)/6)*.7);
    if(ROUGH.has(k))col.set(P.rough).multiplyScalar(.9+.15*hash2(i,j,4));if(f&&f.t==='spot')col.set(P.spot);inst.setColorAt(n,col);n++}
   S.add(inst);
   const W=N+1.8,pl=new T.Mesh(tileGeo(T,W,.7,.5,.07),M(P.plinth,{map:tWood,roughness:night?.5:.55}));pl.position.y=-.68;pl.receiveShadow=true;pl.castShadow=true;S.add(pl);
   const base=new T.Mesh(tileGeo(T,W+.5,.25,.6,.05),M(P.base,{roughness:.7}));base.position.y=-.93;base.receiveShadow=true;S.add(base);
   if(night){const am=new T.MeshBasicMaterial({color:'#9184d9'}),e=N/2+.55;[[0,e,W-1.3,.018],[0,-e,W-1.3,.018],[e,0,.018,W-1.3],[-e,0,.018,W-1.3]].forEach(a=>{const b=new T.Mesh(new T.BoxGeometry(a[2],.012,a[3]),am);b.position.set(a[0],.03,a[1]);S.add(b)});
    [[e,e],[-e,e],[e,-e],[-e,-e]].forEach(p=>{const g=glow('#9184d9',.9,.55);g.position.set(p[0],.06,p[1]);S.add(g)})}
  }else{
   const EXT=N+2,seg=150,g=new T.PlaneGeometry(EXT,EXT,seg,seg);g.rotateX(-Math.PI/2);const pos=g.attributes.position,cols=new Float32Array(pos.count*3),col=new T.Color();
   const gA=C(P.grass[0]),gB=C(P.grass[1]),dC=C(P.dirt),rC=C(P.rough);
   for(let i=0;i<pos.count;i++){const x=pos.getX(i),z=pos.getZ(i),y=top(x,z);pos.setY(i,y);const ci=Math.round(x+H),cj=Math.round(z+H),k=key(ci,cj);
    col.copy(gA).lerp(gB,fbm(x*.7,z*.7,12));const vis=Math.min(1,(VIS.get(k)||0)/6);const dd=Math.max(Math.abs(x-(ci-H)),Math.abs(z-(cj-H)));col.lerp(dC,vis*.75*(1-Math.max(0,dd-.3)*1.6));
    if(ROUGH.has(k))col.lerp(rC,.75*(1-Math.max(0,dd-.25)*1.4));col.multiplyScalar(.9+.18*(y-.3));cols[i*3]=col.r;cols[i*3+1]=col.g;cols[i*3+2]=col.b}
   g.setAttribute('color',new T.BufferAttribute(cols,3));g.computeVertexNormals();
   const tg2=makeTex(T,128,(x,y)=>.86+.2*(fbm(x/10,y/10,3)-.5)+.08*(hash2(x,y,1)-.5),14);
   const ground=new T.Mesh(g,M('#ffffff',{vertexColors:true,map:tg2,roughness:.95}));ground.receiveShadow=true;ground.castShadow=true;S.add(ground);
   const bands=[[.07,'#4d6b33'],[.32,'#5a412e'],[.62,'#76543a'],[.95,'#8c7658'],[1.35,'#6f6a64'],[9,'#4e4a48']].map(b=>[b[0],C(b[1])]);
   const sideMat=M('#ffffff',{vertexColors:true,map:makeTex(T,128,(x,y)=>.82+.3*(fbm(x/6,y/3,40)-.5),4),roughness:.97,side:T.DoubleSide});
   const side=(x0,z0,x1,z1)=>{const cnt=seg+1,rows=36,vs=[],cs=[],ix=[];for(let r=0;r<=rows;r++)for(let k=0;k<cnt;k++){const t=k/seg,x=x0+(x1-x0)*t,z=z0+(z1-z0)*t,yt=top(x,z),bot=-1.7-.9*fbm(x*.5+9,z*.5+9,21),q=r/rows,y=yt+(bot-yt)*(q*q*.35+q*.65);vs.push(x,y,z);const w=x+z,d=yt-y+.07*Math.sin(w*1.7)+.1*(fbm(w*.6,y*1.5,31)-.5);let c=bands[bands.length-1][1];for(const b of bands)if(d<b[0]){c=b[1];break}col.copy(c).multiplyScalar(.88+.2*hash2(k,r,7));cs.push(col.r,col.g,col.b)}
    for(let r=0;r<rows;r++)for(let k=0;k<seg;k++){const a=r*cnt+k,b=a+1,c=a+cnt,d=c+1;ix.push(a,c,b,b,c,d)}const sg=new T.BufferGeometry();sg.setAttribute('position',new T.Float32BufferAttribute(vs,3));sg.setAttribute('color',new T.Float32BufferAttribute(cs,3));const uv=[];for(let r=0;r<=rows;r++)for(let k=0;k<cnt;k++)uv.push(k/seg*3,r/rows);sg.setAttribute('uv',new T.Float32BufferAttribute(uv,2));sg.setIndex(ix);sg.computeVertexNormals();const m=new T.Mesh(sg,sideMat);m.castShadow=true;m.receiveShadow=true;S.add(m)};
   const E=EXT/2;side(-E,E,E,E);side(E,E,E,-E);side(E,-E,-E,-E);side(-E,-E,-E,E);
   const sh=new T.Mesh(new T.PlaneGeometry(22,22),new T.MeshBasicMaterial({map:gTex,color:'#000',transparent:true,opacity:.55,depthWrite:false}));sh.rotation.x=-Math.PI/2;sh.position.y=-4.2;S.add(sh);
   for(let i=0;i<6;i++){const r=new T.Mesh(new T.DodecahedronGeometry(.18+rnd()*.25,0),M('#6f6a64',{flatShading:true,map:tStone}));const a=rnd()*6.28,d=5+rnd()*3;r.position.set(Math.cos(a)*d,-2.4-rnd()*1.2,Math.sin(a)*d);r.rotation.set(rnd()*3,rnd()*3,0);cast(r);S.add(r)}
  }
  // rocks on rough ground
  {const rg=new T.DodecahedronGeometry(.1,1),pa=rg.attributes.position,v=new T.Vector3();for(let i=0;i<pa.count;i++){v.fromBufferAttribute(pa,i);v.multiplyScalar(1+.25*(fbm(v.x*20,v.y*20+v.z*13,3)-.5));pa.setXYZ(i,v.x,v.y,v.z)}rg.computeVertexNormals();
   const list=[];ROUGH.forEach(k=>{const[i,j]=k.split(',').map(Number);const n=2+Math.floor(hash2(i,j,8)*3);for(let q=0;q<n;q++)list.push([i-H+(hash2(i,j,q*3)-.5)*.6,j-H+(hash2(i,j,q*3+1)-.5)*.6,.6+hash2(i,j,q*3+2)*1.1])});
   const im=new T.InstancedMesh(rg,M(P.rock,{map:tStone,roughness:.8,flatShading:true}),list.length),m4=new T.Matrix4(),q=new T.Quaternion(),e=new T.Euler(),col=new T.Color();
   list.forEach((r,i)=>{e.set(r[0]*3,r[1]*5,r[2]);q.setFromEuler(e);m4.compose(new T.Vector3(r[0],top(r[0],r[1])+.03*r[2],r[1]),q,new T.Vector3(r[2]*1.2,r[2]*.8,r[2]));im.setMatrixAt(i,m4);im.setColorAt(i,col.set(P.rock).multiplyScalar(.8+.35*hash2(i,7,2)))});cast(im);S.add(im)}
  // grass tufts + flowers
  {const tuftG=new T.ConeGeometry(.016,.13,4);tuftG.translate(0,.06,0);const cnt=island?3600:900,im=new T.InstancedMesh(tuftG,M('#ffffff',{roughness:.8}),cnt),m4=new T.Matrix4(),q=new T.Quaternion(),e=new T.Euler(),col=new T.Color(),ext=island?7:6;let n=0,tries=0;
   const fl=[];while(n<cnt&&tries<cnt*6){tries++;const x=(rnd()*2-1)*ext*.98,z=(rnd()*2-1)*ext*.98,ci=Math.round(x+H),cj=Math.round(z+H),k=key(ci,cj);if(!island&&(ci<0||cj<0||ci>=N||cj>=N))continue;if(feat.has(k)||ROUGH.has(k)||(VIS.get(k)||0)>2)continue;
    if(!island){const dx=Math.abs(x-(ci-H)),dz=Math.abs(z-(cj-H));if(dx>.42||dz>.42)continue}
    const cl=fbm(x*.8,z*.8,44);if(rnd()>.35+cl*.8)continue;e.set((rnd()-.5)*.5,rnd()*6.28,(rnd()-.5)*.5);q.setFromEuler(e);const s=.6+rnd()*.9;m4.compose(new T.Vector3(x,top(x,z)-.01,z),q,new T.Vector3(s,s*(.8+rnd()*.6),s));im.setMatrixAt(n,m4);im.setColorAt(n,col.set(P.tuft).lerp(C(P.grass[1]),rnd()).multiplyScalar(.8+rnd()*.4));n++;if(!night&&rnd()<.06)fl.push([x,z])}
   im.count=n;im.receiveShadow=true;S.add(im);
   if(fl.length){const fg=new T.IcosahedronGeometry(.02,1),fm=new T.InstancedMesh(fg,M('#ffffff',{roughness:.5}),fl.length),fc=['#f4efe2','#f2d36b','#e7a3b5','#c9c4f2'];fl.forEach((f,i)=>{m4.makeTranslation(f[0],top(f[0],f[1])+.1,f[1]);fm.setMatrixAt(i,m4);fm.setColorAt(i,col.set(fc[i%4]))});fm.castShadow=true;S.add(fm)}}
  // trees
  const leafM=P.leaf.map(c=>M(c,{roughness:.78})),barkM=M(P.bark,{map:tWood,roughness:.9});
  const tree=(kind,s)=>{const g=new T.Group();const tr=new T.Mesh(new T.CylinderGeometry(.03,.05,.38,7),barkM);tr.position.y=.19;g.add(tr);
   if(kind===0){[[0,.5,0,.22],[.1,.42,.06,.16],[-.09,.44,-.05,.15],[0,.64,.02,.14]].forEach((b,i)=>{const m=new T.Mesh(blobGeo(T,b[3],i*3+s*11,.35),leafM[i%3]);m.position.set(b[0],b[1],b[2]);g.add(m)})}
   else{[[.42,.26,.34],[.6,.2,.3],[.76,.13,.24]].forEach((c,i)=>{const m=new T.Mesh(new T.ConeGeometry(c[1],c[2],9),leafM[(i+1)%3]);m.position.y=c[0];g.add(m)})}
   g.scale.setScalar(s);g.rotation.y=s*17;return cast(g)};
  {const spots=[];const ring=island?[6.3,6.85]:[6.25,6.75];for(let t=0;t<220&&spots.length<(island?34:22);t++){const side=Math.floor(rnd()*4),u=(rnd()*2-1)*(ring[1]);const d=ring[0]+rnd()*(ring[1]-ring[0]);const p=side===0?[u,d]:side===1?[u,-d]:side===2?[d,u]:[-d,u];if(spots.some(q=>Math.hypot(q[0]-p[0],q[1]-p[1])<.55))continue;spots.push(p)}
   spots.forEach((p,i)=>{if(!island&&rnd()<.3){const r=new T.Mesh(new T.DodecahedronGeometry(.12+rnd()*.12,0),M(P.rock,{flatShading:true,map:tStone}));r.position.set(p[0],island?top(p[0],p[1]):.06,p[1]);r.rotation.set(rnd()*3,rnd()*3,0);S.add(cast(r));return}
    const t=tree(rnd()<.62?0:1,.9+rnd()*.7);t.position.set(p[0],island?top(p[0],p[1])-.02:.02,p[1]);S.add(t)})}
  // sources
  const glows=[],flicker=[],chims=[];
  BUSH.forEach((c,k)=>{const x=c[0]-H-.1,z=c[1]-H-.1,y=top(x,z),g=new T.Group();g.position.set(x,y,z);
   const bl=[[0,.2,0,.24],[.17,.14,.08,.17],[-.15,.13,.1,.16],[.05,.15,-.17,.17],[-.06,.33,-.02,.15]];const pts=[];
   bl.forEach((b,i)=>{const m=new T.Mesh(blobGeo(T,b[3],k*9+i*2,.3),leafM[i%3]);m.position.set(b[0],b[1],b[2]);g.add(m);pts.push(b)});
   const bm=new T.MeshPhysicalMaterial({color:night?'#a0324a':'#c42f3c',roughness:.25,clearcoat:1,clearcoatRoughness:.2,emissive:night?'#5a1020':'#000',emissiveIntensity:.6}),bg=new T.SphereGeometry(.032,12,10);
   const r=rng(40+k);for(let q=0;q<STOCK[k]*2;q++){const b=pts[q%pts.length],th=r()*6.28,ph=r()*1.2;const m=new T.Mesh(bg,bm);m.position.set(b[0]+Math.cos(th)*Math.sin(ph)*b[3]*.98,b[1]+Math.cos(ph)*b[3]*.9,b[2]+Math.sin(th)*Math.sin(ph)*b[3]*.98);g.add(m)}
   S.add(cast(g))});
  const stoneM=M(P.stone,{map:tStone,roughness:.85}),woodM=M(P.wood,{map:tWood,roughness:.75});
  WELL.forEach((c,k)=>{const x=c[0]-H-.1,z=c[1]-H-.1,y=top(x,z),g=new T.Group();g.position.set(x,y,z);
   const prof=[[.17,0],[.29,0],[.3,.03],[.3,.2],[.28,.23],[.2,.23],[.17,.2],[.17,.05]].map(p=>new T.Vector2(p[0],p[1]));const ring=new T.Mesh(new T.LatheGeometry(prof,28),stoneM);g.add(ring);
   const wm=new T.MeshPhysicalMaterial({color:P.water,roughness:.06,metalness:0,clearcoat:1,emissive:night?'#1d6a95':'#0b2a3a',emissiveIntensity:night?.9:.25});const w=new T.Mesh(new T.CircleGeometry(.17,28),wm);w.rotation.x=-Math.PI/2;w.position.y=.15;g.add(w);
   [-.24,.24].forEach(px=>{const p=new T.Mesh(new T.BoxGeometry(.04,.5,.04),woodM);p.position.set(px,.37,0);g.add(p)});
   const bar=new T.Mesh(new T.CylinderGeometry(.018,.018,.54,8),woodM);bar.rotation.z=Math.PI/2;bar.position.y=.5;g.add(bar);
   [-1,1].forEach(sd=>{const rf=new T.Mesh(new T.BoxGeometry(.66,.02,.26),M(P.roof,{roughness:.8,map:tWood}));rf.position.set(0,.64,sd*.1);rf.rotation.x=sd*.62;g.add(rf)});
   const bk=new T.Mesh(new T.CylinderGeometry(.045,.035,.07,12),woodM);bk.position.set(.08,.35,0);g.add(bk);
   S.add(cast(g));if(night){const gl=glow('#5fb8ff',.9,.8);gl.position.set(x,y+.2,z);S.add(gl);glows.push(gl)}});
  SPOT.forEach(c=>{const x=c[0]-H,z=c[1]-H,y=top(x,z);const s=new T.Mesh(new T.CylinderGeometry(.34,.37,.05,9),M(P.stone,{flatShading:true,map:tStone}));s.position.set(x,y+.02,z);S.add(cast(s));const st=new T.Mesh(new T.BoxGeometry(.09,.32,.06),stoneM);st.position.set(x+.2,y+.17,z-.18);st.rotation.set(.05,.4,.08);S.add(cast(st))});
  const wallM=M(P.wall,{roughness:.9,map:tGrain}),roofM=M(P.roof,{roughness:.7,map:tWood}),winM=new T.MeshStandardMaterial({color:'#3a2a1c',emissive:'#ffb35c',emissiveIntensity:night?2.2:.15});
  HOMES.forEach((h,k)=>{const x=h[0]-H-.08,z=h[1]-H-.08,y=top(x,z),g=new T.Group(),p=h[2];g.position.set(x,y,z);g.rotation.y=[0,.5,-.3,1.57,.2,0][k];
   const slab=new T.Mesh(new T.BoxGeometry(.62,.05,.56),stoneM);slab.position.y=.025;g.add(slab);
   if(p>=1){const wl=new T.Mesh(new T.BoxGeometry(.5,.3,.42),wallM);wl.position.y=.2;g.add(wl);
    const tri=new T.Shape();tri.moveTo(-.31,0);tri.lineTo(.31,0);tri.lineTo(0,.24);tri.lineTo(-.31,0);const rg=new T.ExtrudeGeometry(tri,{depth:.52,bevelEnabled:true,bevelThickness:.012,bevelSize:.012,bevelSegments:1});rg.translate(0,0,-.26);const rf=new T.Mesh(rg,roofM);rf.position.y=.35;g.add(rf);
    const dr=new T.Mesh(new T.BoxGeometry(.11,.18,.02),woodM);dr.position.set(0,.14,.215);g.add(dr);
    [-.15,.15].forEach(wx=>{const wn=new T.Mesh(new T.BoxGeometry(.07,.07,.02),winM);wn.position.set(wx,.24,.215);g.add(wn)});
    const ch=new T.Mesh(new T.BoxGeometry(.06,.14,.06),stoneM);ch.position.set(.14,.52,-.08);g.add(ch);
    if(night){const gl=glow('#ffae55',.55,.9);gl.position.set(0,.24,.26);g.add(gl);glows.push(gl)}}
   else if(p>0){[[-.23,-.19],[.23,-.19],[-.23,.19],[.23,.19]].forEach(c=>{const po=new T.Mesh(new T.BoxGeometry(.035,.34,.035),woodM);po.position.set(c[0],.22,c[1]);g.add(po)});
    [-.19,.19].forEach(zz=>{const b=new T.Mesh(new T.BoxGeometry(.5,.03,.03),woodM);b.position.set(0,.38,zz);g.add(b)});
    const n=Math.round(p*6);for(let i=0;i<n;i++){const pl=new T.Mesh(new T.BoxGeometry(.46,.045,.02),woodM);pl.position.set(0,.08+i*.05,-.19);g.add(pl)}
    for(let i=0;i<3;i++){const lg=new T.Mesh(new T.CylinderGeometry(.025,.025,.3,8),woodM);lg.rotation.z=Math.PI/2;lg.position.set(.05,.07+(i===2?.045:0),.32+(i===2?0:i*.05-.025));g.add(lg)}}
   else{const br=new T.Mesh(new T.CapsuleGeometry(.07,.26,4,10),M('#7d6a8e',{roughness:.95}));br.rotation.z=Math.PI/2;br.position.set(-.05,.1,-.1);g.add(br);
    const r=rng(9);for(let i=0;i<7;i++){const a=i/7*6.28,st=new T.Mesh(new T.DodecahedronGeometry(.03,0),stoneM);st.position.set(.14+Math.cos(a)*.08,.06,.14+Math.sin(a)*.08);g.add(st)}
    const em=new T.Mesh(new T.IcosahedronGeometry(.035,1),new T.MeshStandardMaterial({color:'#3a1a0a',emissive:'#ff7a2a',emissiveIntensity:night?3:1.2}));em.position.set(.14,.07,.14);g.add(em);
    const pl=new T.PointLight('#ff8a3a',night?2.2:.6,2.2,2);pl.position.set(.14,.2,.14);g.add(pl);flicker.push(pl);if(night){const gl=glow('#ff8a3a',.8,.9);gl.position.set(.14,.1,.14);g.add(gl);flicker.push(gl)}}
   if(P.island&&p>=1){g.updateMatrixWorld(true);const cp=new T.Vector3(.14,.6,-.08);g.localToWorld(cp);chims.push(cp)}
   S.add(cast(g))});
  const puffs=[];chims.forEach((cp,ci)=>{for(let i=0;i<7;i++){const s=new T.Sprite(new T.SpriteMaterial({map:gTex,color:night?'#8c8aa6':'#e4e0da',transparent:true,depthWrite:false,opacity:0}));s.userData={cp,o:i/7+ci*.13};S.add(s);puffs.push(s)}});
  // people
  const cap=new T.CapsuleGeometry(.07,.14,4,12),headG=new T.SphereGeometry(.062,18,14),hairG=new T.SphereGeometry(.066,18,12,0,Math.PI*2,0,Math.PI*.52);
  PEOPLE.forEach(p=>{const g=new T.Group(),bd=new T.Group();g.add(bd);const b=new T.Mesh(cap,M(p.color,{roughness:.72,map:tGrain}));b.position.y=.14;bd.add(b);
   const hd=new T.Mesh(headG,M(p.skin,{roughness:.55}));hd.position.y=.33;bd.add(hd);const hr=new T.Mesh(hairG,M(p.hair,{roughness:.6}));hr.position.set(0,.338,-.006);hr.rotation.x=-.25;bd.add(hr);
   if(p.carry){const pk=new T.Mesh(new T.BoxGeometry(.1,.11,.06),M('#7a5334',{map:tWood}));pk.position.set(0,.19,-.08);bd.add(pk);const im=p.carry==='food'?new T.MeshPhysicalMaterial({color:'#c42f3c',roughness:.3,clearcoat:1}):new T.MeshPhysicalMaterial({color:'#3b8fb0',roughness:.1,clearcoat:1});for(let i=0;i<2;i++){const s=new T.Mesh(new T.SphereGeometry(.028,10,8),im);s.position.set(-.025+i*.05,.26,-.08);bd.add(s)}}
   if(p.need){const mk=new T.Mesh(new T.OctahedronGeometry(.032,0),new T.MeshStandardMaterial({color:p.need,emissive:p.need,emissiveIntensity:1.3}));mk.position.y=.5;g.add(mk);p.mk=mk;if(night||p.emergency){const gl=glow(p.need,p.emergency?.55:.3,.8);gl.position.y=.5;g.add(gl);p.mg=gl}}
   if(night){const l=glow('#ffc37a',.32,.9);l.position.set(.1,.16,.06);g.add(l)}
   cast(g);S.add(g);p.g=g;p.bd=bd});
  // focus ring + help arc
  const fr=new T.Mesh(new T.RingGeometry(.2,.235,48),new T.MeshBasicMaterial({color:'#9184d9',transparent:true,opacity:.95,depthWrite:false}));fr.rotation.x=-Math.PI/2;S.add(fr);const frg=glow('#9184d9',.9,.5);S.add(frg);
  const beads=[],bm=new T.MeshBasicMaterial({color:'#b5abfc'});for(let i=0;i<22;i++){const b=new T.Mesh(new T.SphereGeometry(.022,8,6),bm);S.add(b);beads.push(b)}
  const flies=[];if(night){for(let i=0;i<40;i++){const f=glow('#e4ffb0',.12,.8);f.userData={x:(rnd()*2-1)*6,z:(rnd()*2-1)*6,y:.4+rnd()*1.2,p:rnd()*6.28};S.add(f);flies.push(f)}}
  // lights
  const sun=new T.DirectionalLight(P.sun[0],P.sun[1]);sun.position.set(...P.sun[2]);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-11,right:11,top:11,bottom:-11,near:1,far:50});sun.shadow.bias=-.0004;sun.shadow.normalBias=.025;S.add(sun);
  S.add(new T.HemisphereLight(P.hemi[0],P.hemi[1],P.hemi[2]));const fill=new T.DirectionalLight(P.fill[0],P.fill[1]);fill.position.set(-P.sun[2][0],5,-P.sun[2][2]);S.add(fill);
  // camera + controls
  let az=.78,el=P.el,drag=null,idle=0;
  cv.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY};cv.setPointerCapture(e.pointerId);cv.style.cursor='grabbing'});
  cv.addEventListener('pointermove',e=>{if(!drag)return;az-=(e.clientX-drag.x)*.006;el=Math.max(.3,Math.min(1.25,el+(e.clientY-drag.y)*.004));drag={x:e.clientX,y:e.clientY};idle=0});
  const up=()=>{drag=null;cv.style.cursor='grab'};cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
  const ray=new T.Raycaster(),ndc=new T.Vector2(),tv=new T.Vector3();let dn=null;cv.addEventListener('pointerdown',e=>{dn={x:e.clientX,y:e.clientY}});
  cv.addEventListener('pointerup',e=>{if(!dn||Math.hypot(e.clientX-dn.x,e.clientY-dn.y)>5)return;const r=cv.getBoundingClientRect();ndc.set((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height)*2+1);ray.setFromCamera(ndc,cam);let best=null,bd=.4;PEOPLE.forEach(p=>{tv.copy(p.g.position);tv.y+=.22;const d=ray.ray.distanceToPoint(tv);if(d<bd){bd=d;best=p}});if(best){const rk=Object.keys(this).find(k=>k.startsWith('__reactProps'));const fn=this.onPick||(rk&&this[rk].onPick);if(typeof fn==='function')fn(best.id);this.dispatchEvent(new CustomEvent('pick',{detail:best.id}))}});
  let aspect=1.6;const resize=()=>{const w=Math.max(1,this.clientWidth),h=Math.max(1,this.clientHeight);R.setSize(w,h,false);aspect=w/h;cam.aspect=aspect;cam.updateProjectionMatrix()};this._ro=new ResizeObserver(resize);this._ro.observe(this);resize();
  let vis=true;this._io=new IntersectionObserver(es=>{vis=es[0].isIntersecting});this._io.observe(this);
  const clock=new T.Clock();let simT=412,now=0;const v3=new T.Vector3(),a3=new T.Vector3(),b3=new T.Vector3(),m3=new T.Vector3();
  const loop=()=>{this._raf=requestAnimationFrame(loop);const dt=Math.min(clock.getDelta(),.05);if(!vis)return;now+=dt;if(this.isPlaying)simT+=dt*2;idle+=dt;if(!drag&&idle>1.5)az+=dt*.03;
   const dist=P.dist*Math.max(1,1.55/aspect);cam.position.set(dist*Math.cos(el)*Math.sin(az),dist*Math.sin(el)-.4,dist*Math.cos(el)*Math.cos(az));cam.lookAt(0,island?-.35:-.2,0);
   const fid=this.focusId;
   PEOPLE.forEach(p=>{const L=p.frames.length,tt=simT+p.phase,k=Math.floor(tt),f=tt-k,a=p.frames[((k%L)+L)%L],b=p.frames[(((k+1)%L)+L)%L],s=f*f*(3-2*f),x=a[0]+(b[0]-a[0])*s,z=a[1]+(b[1]-a[1])*s,mv=a[0]!==b[0]||a[1]!==b[1];
    p.g.position.set(x,top(x,z)+(mv?Math.abs(Math.sin(f*Math.PI))*.03:0),z);if(mv){let tr=Math.atan2(b[0]-a[0],b[1]-a[1]),d=tr-p.g.rotation.y;d=Math.atan2(Math.sin(d),Math.cos(d));p.g.rotation.y+=d*.18;p.bd.rotation.z=Math.sin(f*Math.PI*2)*.06}else p.bd.rotation.z*=.9;
    if(p.work){p.bd.rotation.x=.18+.14*Math.max(0,Math.sin(now*7));p.g.rotation.y=Math.PI}if(p.sit){p.bd.scale.y=.86;p.bd.rotation.x=.12}
    if(p.mk){p.mk.position.y=.5+Math.sin(now*2.2+p.phase)*.025;p.mk.rotation.y=now*1.5;if(p.emergency){const s=1+.35*Math.max(0,Math.sin(now*5));p.mk.scale.setScalar(s);if(p.mg)p.mg.material.opacity=.5+.4*Math.max(0,Math.sin(now*5))}}
    if(p.id===fid){fr.position.set(x,top(x,z)+.02,z);const s=1+.08*Math.sin(now*3);fr.scale.setScalar(s);frg.position.set(x,top(x,z)+.05,z)}});
   fr.visible=frg.visible=!!PEOPLE.find(p=>p.id===fid);
   const A=PEOPLE[3].g.position,B=PEOPLE[5].g.position;a3.set(A.x,A.y+.45,A.z);b3.set(B.x,B.y+.45,B.z);m3.addVectors(a3,b3).multiplyScalar(.5);m3.y+=.4+a3.distanceTo(b3)*.25;const ph=(now*.5)%1;
   beads.forEach((bd,i)=>{const t=i/(beads.length-1),u=1-t;v3.set(u*u*a3.x+2*u*t*m3.x+t*t*b3.x,u*u*a3.y+2*u*t*m3.y+t*t*b3.y,u*u*a3.z+2*u*t*m3.z+t*t*b3.z);bd.position.copy(v3);let d=Math.abs(t-ph);d=Math.min(d,1-d);bd.scale.setScalar(.7+1.1*Math.max(0,1-d*8))});
   flicker.forEach((f,i)=>{const n=.8+.2*Math.sin(now*13+i)+.1*Math.sin(now*29+i*2);if(f.isLight)f.intensity=(night?2.2:.6)*n;else f.material.opacity=.7*n});
   glows.forEach((g,i)=>{g.material.opacity=.75+.12*Math.sin(now*1.3+i)});
   puffs.forEach(p=>{const u=p.userData,l=(now*.22+u.o)%1;p.position.set(u.cp.x+l*.35+Math.sin(l*6+u.o*9)*.05,u.cp.y+l*1.3,u.cp.z-l*.15);const sc=.12+l*.55;p.scale.set(sc,sc,1);p.material.opacity=.32*(1-l)*Math.min(1,l*6)});
   flies.forEach(f=>{const u=f.userData;f.position.set(u.x+Math.sin(now*.4+u.p)*.6,u.y+Math.sin(now*.9+u.p*2)*.15,u.z+Math.cos(now*.3+u.p)*.6);f.material.opacity=.4+.5*Math.max(0,Math.sin(now*1.7+u.p*3))});
   R.render(S,cam)};
  loop();
 }
}
customElements.define('sim-world',SimWorld);
})();
